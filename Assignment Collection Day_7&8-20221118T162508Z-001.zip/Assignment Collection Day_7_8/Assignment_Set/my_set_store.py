# # 3)  Create a program named "my_set_store" which support following operations on two sets
# #     provided by user
# #
# # for ex:
# A = {1, 2, 3, 4, 5}
# B = {18, 19, 20, 21}
# # is provided by the user
# #
# # Operations supported by our program are :
# # 	1: Union
# # 	2: Intersection
# # 	3: A-B
# # 	4: B-A
# # 	5: Take a element from user and Display if that element is a member of set B
# # 	6: Display number of elements in the set A
# #     7: Display number of elements in the set B
# # 	8: Add an element taken from the user to the set A
# # 	9: Add multiple elements taken from the user to the set A
# # 	10: Remove an element taken from the user from set A

A = {1, 2, 3, 4, 5}
B = {18, 19, 20, 21}

while True:
    print("\n============================================================================"
          "\n1: Union"
          "\n2: Intersection"
          "\n3: A-B"
          "\n4: B-A"
          "\n5: Take a element from user and Display if that element is a member of set B "
          "\n6: Display number of elements in the set A"
          "\n7: Display number of elements in the set B"
          "\n8: Add an element taken from the user to the set A"
          "\n9: Add multiple elements taken from the user to the set A"
          "\n10: Remove an element taken from the user from set A"
          "\n================================================================================")

    ch = int(input("Please Enter your choice::"))

    match ch:
        case 1:
            print(A.union(B))

        case 2:
            print(A.intersection(B))

        case 3:
            print(A.difference(B))

        case 4:
            print(B.difference(A))

        case 5:

            a = int(input("Enter an element"))
            if a in B:
                print(a)
            else:
                print("No")

        case 6:
            print(len(A))

        case 7:
            print(len(B))

        case 8:
            b = int(input("Enter the element you want to add:: "))
            A.add(b)
            print("Element added Successfully")

        case 9:
            x = int(input("Enter the elements you want to add"))
            i = 0
            while i < x:
                b = int(input("Enter the element you want to add:: "))
                A.add(b)
                i += 1

        case 10:
            y = int(input("Enter the element you want to delete"))
            A.remove(y)

        case 11:
            break

        case _:
            print("Invalid Option")
