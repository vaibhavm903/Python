from functions_definitions import *

flag = True

while flag:
    print("\nChoose following operations"
          "\n==========================================================================="
          "\n1:  Display number of elements in the members list"
          "\n2:  Add an element to the members collection like 'Sehwag'"
          "\n3:  Add elements to the members collection like ['David','Bret','Sanju']"
          "\n4:  Remove a member from the collection at a given subscript"
          "\n5:  Remove the last member from the collection"
          "\n6:  Display third, fourth and fifth element from the collection"
          "\n7:  Exit!"
          "\n===========================================================================")

    c = int(input("Please Enter Your Choice::"))

    match c:
        case 1:
            print(members)
            print("Number of Element in the Members list::", len(members))

        case 2:
            name = input("Please Enter the new members name::")
            add_member(name)

        case 3:
            members_names = input("Enter the list of members name to added::")
            members_list = members_names.split(" ")
            add_members_list(members_list)

        case 4:
            name = input("Enter the member name to delete from the list::")
            members.remove(name)
            print("Member has been deleted")

        case 5:
            members.pop()
            print("Last member of the list has been deleted...")

        case 6:
            print("3rd, 4th and 5th members from the list::", members[2:5])

        case 7:
            flag = False
            print("Exit.....!!")

        case _:
            print("Invalid Input ... :(")
