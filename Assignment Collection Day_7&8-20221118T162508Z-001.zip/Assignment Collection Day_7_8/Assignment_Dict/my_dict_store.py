# 2) Create a program named "my_dict_store" which support following operations on
# dictionary named "capitals" which would have keys as their country and values as their capitals
# respectively from the user
# for ex: "India" : "New Delhi" ,"USA" : "Washington DC","Nepal": "Kathmandu","Ukraine" : "Kyiv"
# is provided by the user
#
# Operations supported by our program are : 1: Display number of elements in the capitals collection 2: Add an
# element to the capitals collection like --> Afghanistan: Kabul 3: Add multiple elements to the capitals collection
# like -->  Albania:Tirana,Algeria:Algiers,Andorra:Andorra la Vella 4: Remove an element from the collection
#
# Keep asking the user for the operation in this store untill he chooses to exit from the program

from function_definitions import *

while True:
    print("""
    \n\t=====================================================================================================================
    1: Display number of elements in the capitals collection
    2: Add an element to the capitals collection like  --> Afghanistan: Kabul
    3: Add multiple elements to the capitals collection like -->  Albania:Tirana,Algeria:Algiers,Andorra:Andorra la Vella
    4: Remove an element from the collection
    5: Exit
    ======================================================================================================================
    """)

    ch = int(input("Choose option::"))

    match ch:

        case 1:
            print(capitals)
            print("The total number of elements in the capitals collection::", len(capitals))

        case 2:
            add_capitals()

        case 3:
            i = 0
            n = int(input("Please enter the number of elements you want to add::"))

            while i < n:
                add_capitals()
                i += 1

        case 4:
            if len(capitals) == 0:
                print("Collection is empty....")
            else:
                print("Deleted Item::", capitals.popitem())

        case 5:
            print("Exited...!!!")
            break

        case _:
            print("Invalid option .... :(")
