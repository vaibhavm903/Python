capitals = {}


def add_capitals():
    key = input("Enter the country name::")
    if key in capitals:
        print("Entry is already present ... ")
    else:
        value = input("Enter the capital name of the country::")
        capitals[key] = value
        print("Element is added....")
